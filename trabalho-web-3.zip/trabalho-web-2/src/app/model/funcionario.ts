export interface Funcionario {
    
    id?: number,
    nome: String,
    foto: String,
    email: String,
    subobjeto: {
        propriedade1: String;
        propriedade2: String;
        }

}